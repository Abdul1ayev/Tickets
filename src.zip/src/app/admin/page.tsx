"use client";
import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Link from "next/link";
import { supabase } from "./../../supabaseClient";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";


interface Ticket {
  id?: number;
  from: string;
  to: string;
  date: string;
  time: string;
  price: any;
}

const Admin: React.FC = () => {
  const [ticket, setTicket] = useState<Ticket>({
    from: "",
    to: "",
    date: "",
    time: "",
    price: "",
  });
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetchTickets();
  }, []);

  const fetchTickets = async () => {
    setLoading(true);
    const { data, error } = await supabase.from("tickets").select("*");
    if (error) {
      console.error("Error fetching tickets:", error);
      toast.error("Error fetching tickets.");
    } else {
      setTickets(data || []);
    }
    setLoading(false);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    setTicket({ ...ticket, [e.target.name]: e.target.value });
  };

  const handleSaveOrUpdate = async () => {
    if (
      !ticket.from ||
      !ticket.to ||
      !ticket.date ||
      !ticket.time ||
      ticket.price <= 0
    ) {
      toast.error("Please fill in all fields correctly.");
      return;
    }

    const newTicket = {
      from: ticket.from,
      to: ticket.to,
      date: ticket.date,
      time: ticket.time,
      price: ticket.price,
    };

    const { data, error } = await supabase.from("tickets").insert([newTicket]);
    if (error) {
      console.error("Error saving/updating ticket:", error);
      toast.error("Error saving/updating ticket.");
    } else {
      toast.success("Ticket added successfully!");
      setTicket({
        from: "",
        to: "",
        date: "",
        time: "",
        price: "",
      });
      fetchTickets();
    }
  };

  const handleEdit = (t: Ticket) => {
    setTicket(t);
  };

  const handleDelete = async (id?: number) => {
    if (!id || !window.confirm("Are you sure you want to delete this ticket?"))
      return;

    const { error } = await supabase.from("tickets").delete().eq("id", id);
    if (error) {
      console.error("Error deleting ticket:", error);
      toast.error("Error deleting ticket.");
    } else {
      toast.success("Ticket deleted successfully!");
      fetchTickets();
    }
  };

  const regions = [
    "Sirdaryo",
    "Navoiy",
    "Jizzax",
    "Xorazm",
    "Buxoro",
    "Surxondaryo",
    "Namangan",
    "Andijon",
    "Qashqadaryo",
    "Samarqand",
    "Fargʻona",
    "Toshkent",
  ];

  const times = [
    "08:00",
    "09:30",
    "11:30",
    "16:00",
    "18:00",
    "20:30",
    "22:00",
    "22:30",
    "23:00",
  ];

  return (
    <div className="container p-5">
      <Link href="/" className="btn btn-outline-secondary mb-4">
        Back to Home
      </Link>
      <h1 className="text-3xl font-bold text-center mb-6 text-primary">
        Admin Panel
      </h1>
      <div className="d-flex flex-column flex-lg-row gap-4">
        <div
          className="card shadow-sm p-4 flex-shrink-0"
          style={{ width: "20rem" }}
        >
          <h4 className="text-xl font-semibold mb-4">Create / Edit Ticket</h4>
          <form>
            <div className="mb-3">
              <label className="form-label">From</label>
              <select
                className="form-select"
                name="from"
                value={ticket.from}
                onChange={handleChange}
              >
                <option value="" disabled>
                  Select Region
                </option>
                {regions.map((region) => (
                  <option key={region} value={region}>
                    {region}
                  </option>
                ))}
              </select>
            </div>
            <div className="mb-3">
              <label className="form-label">To</label>
              <select
                className="form-select"
                name="to"
                value={ticket.to}
                onChange={handleChange}
              >
                <option value="" disabled>
                  Select Region
                </option>
                {regions.map((region) => (
                  <option key={region} value={region}>
                    {region}
                  </option>
                ))}
              </select>
            </div>
            <div className="mb-3">
              <label className="form-label">Date</label>
              <input
                type="date"
                className="form-control"
                name="date"
                value={ticket.date}
                onChange={handleChange}
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Time</label>
              <select
                className="form-select"
                name="time"
                value={ticket.time}
                onChange={handleChange}
              >
                <option value="" disabled>
                  Select Time
                </option>
                {times.map((time) => (
                  <option key={time} value={time}>
                    {time}
                  </option>
                ))}
              </select>
            </div>
            <div className="mb-3">
              <label className="form-label">Price (UZS)</label>
              <input
                type="number"
                className="form-control"
                name="price"
                value={ticket.price}
                onChange={handleChange}
              />
            </div>
            <button
              type="button"
              className={`btn ${
                ticket.id ? "btn-warning" : "btn-primary"
              } w-100`}
              onClick={handleSaveOrUpdate}
            >
              {ticket.id ? "Update Ticket" : "Save Ticket"}
            </button>
          </form>
        </div>
        <div className="w-100">
          <h4 className="text-xl font-semibold mb-4">All Tickets</h4>
          {loading ? (
            <div>Loading...</div>
          ) : (
            <table className="table table-bordered table-striped table-hover">
              <thead>
                <tr>
                  <th>#</th>
                  <th>From</th>
                  <th>To</th>
                  <th>Date</th>
                  <th>Time</th>
                  <th>Price</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {tickets.map((t, index) => (
                  <tr key={t.id || index}>
                    <td>{index + 1}</td>
                    <td>{t.from}</td>
                    <td>{t.to}</td>
                    <td>{t.date}</td>
                    <td>{t.time}</td>
                    <td>{t.price} UZS</td>
                    <td>
                      <button
                        className="btn btn-warning btn-sm"
                        onClick={() => handleEdit(t)}
                      >
                        Edit
                      </button>
                      <button
                        className="btn btn-danger btn-sm ms-2"
                        onClick={() => handleDelete(t.id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};

export default Admin;
